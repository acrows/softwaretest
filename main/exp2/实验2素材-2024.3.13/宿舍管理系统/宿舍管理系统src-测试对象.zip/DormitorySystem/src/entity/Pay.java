package entity;

//缴费信息
public class Pay {
    private String sno;
    private double pay_money;
    private String pad_time;
    private double need_money;
    private double paid_money;
    private double diff_money;

    public Pay() {
    }

    public Pay(String sno, double pay_money, String pad_time, double need_money, double paid_money, double diff_money) {
        this.sno = sno;
        this.pay_money = pay_money;
        this.pad_time = pad_time;
        this.need_money = need_money;
        this.paid_money = paid_money;
        this.diff_money = diff_money;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public double getPay_money() {
        return pay_money;
    }

    public void setPay_money(double pay_money) {
        this.pay_money = pay_money;
    }

    public String getPad_time() {
        return pad_time;
    }

    public void setPad_time(String pad_time) {
        this.pad_time = pad_time;
    }

    public double getNeed_money() {
        return need_money;
    }

    public void setNeed_money(double need_money) {
        this.need_money = need_money;
    }

    public double getPaid_money() {
        return paid_money;
    }

    public void setPaid_money(double paid_money) {
        this.paid_money = paid_money;
    }

    public double getDiff_money() {
        return diff_money;
    }

    public void setDiff_money(double diff_money) {
        this.diff_money = diff_money;
    }
}
