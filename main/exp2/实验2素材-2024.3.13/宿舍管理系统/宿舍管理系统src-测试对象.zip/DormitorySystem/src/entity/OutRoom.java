package entity;

//退宿
public class OutRoom {
    private String sno;
    private String out_time;
    private String reason;
    private double need_money;
    private double paid_money;
    private double diff_money;

    public OutRoom() {
    }

    public OutRoom(String sno, String out_time, String reason, double need_money, double paid_money, double diff_money) {
        this.sno = sno;
        this.out_time = out_time;
        this.reason = reason;
        this.need_money = need_money;
        this.paid_money = paid_money;
        this.diff_money = diff_money;
    }

    public String getSno() {
        return sno;
    }

    public String getOut_time() {
        return out_time;
    }

    public String getReason() {
        return reason;
    }

    public double getNeed_money() {
        return need_money;
    }

    public double getPaid_money() {
        return paid_money;
    }

    public double getDiff_money() {
        return diff_money;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public void setOut_time(String out_time) {
        this.out_time = out_time;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setNeed_money(double need_money) {
        this.need_money = need_money;
    }

    public void setPaid_money(double paid_money) {
        this.paid_money = paid_money;
    }

    public void setDiff_money(double diff_money) {
        this.diff_money = diff_money;
    }
}
