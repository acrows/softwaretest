package entity;

//调换房间
public class ReplaceRoom {
    private String sno;
    private String new_rno;
    private String new_bedno;
    private String change_time;

    public ReplaceRoom() {
    }

    public ReplaceRoom(String sno, String new_rno, String new_bedno, String change_time) {
        this.sno = sno;
        this.new_rno = new_rno;
        this.new_bedno = new_bedno;
        this.change_time = change_time;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public String getNew_rno() {
        return new_rno;
    }

    public void setNew_rno(String new_rno) {
        this.new_rno = new_rno;
    }

    public String getNew_bedno() {
        return new_bedno;
    }

    public void setNew_bedno(String new_bedno) {
        this.new_bedno = new_bedno;
    }

    public String getChange_time() {
        return change_time;
    }

    public void setChange_time(String change_time) {
        this.change_time = change_time;
    }
}
