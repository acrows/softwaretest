package entity;

//住宿调整
public class ChangeStay {
    private String sno;
    private int days;
    private double need_money;
    private double paid_money;
    private double diff_money;
    private int extend;//延长(1)或提前(0)住宿

    public ChangeStay() {
    }

    public ChangeStay(String sno, int days, double need_money, double paid_money, double diff_money, int extend) {
        this.sno = sno;
        this.days = days;
        this.need_money = need_money;
        this.paid_money = paid_money;
        this.diff_money = diff_money;
        this.extend = extend;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public double getNeed_money() {
        return need_money;
    }

    public void setNeed_money(double need_money) {
        this.need_money = need_money;
    }

    public double getPaid_money() {
        return paid_money;
    }

    public void setPaid_money(double paid_money) {
        this.paid_money = paid_money;
    }

    public double getDiff_money() {
        return diff_money;
    }

    public void setDiff_money(double diff_money) {
        this.diff_money = diff_money;
    }

    public int getExtend() {
        return extend;
    }

    public void setExtend(int extend) {
        this.extend = extend;
    }
}
